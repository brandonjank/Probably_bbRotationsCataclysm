Probably_bbRotations
====================
https://github.com/backburn/Probably_bbRotations

Rotation automation scripts for World of Warcraft using Probably Engine.

Requires:
  Probably Engine Unlocker - https://probablyengine.com/download.html
  Probably Engine Addon - https://github.com/ProbablyEngine/Probably

Addon Install Guide:
  1. Click 'Download ZIP', bottom right of github page: https://github.com/ProbablyEngine/Probably
  2. Click 'Download ZIP', bottom right of github page: https://github.com/backburn/Probably_bbRotations
  3. Copy the Probably_bbRotations-master and Probably-master folders from the zip files to your World of Warcraft\Interface\AddOns folder.
  4. Rename the Probably-master folder to Probably.
  5. Rename the Probably_bbRotations-master folder to Probably_bbRotations.

Common Controls:
  Left Control - Pause Rotation
  
Supported Classes:
  Druid - Restoration  (untested)
  Hunter - Survival (raid ready)
  Monk - Brewmaster (untested)
  Monk - Windwalker (untested)
  Paladin - Protection (raid ready)
  Shaman - Elemental (raid ready)
  Warrior - Protection (raid ready)
